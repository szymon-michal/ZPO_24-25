# Traffic Violations Management System

A comprehensive application for managing traffic tickets, designed for both police officers and drivers.

## Overview

This system provides a dual interface:
- A JavaFX desktop application for police officers to issue and manage tickets
- A responsive web interface for drivers to view and accept their tickets

## Features

### Police Application (JavaFX)
- Officer authentication via service ID
- Issue new tickets with multiple offenses
- Support for repeat offenses with increased penalties
- View and manage previously issued tickets
- Cancel tickets with reason tracking

### Driver Web Portal
- Login with PESEL number
- View all tickets and total demerit points
- Detailed view of each ticket with offense information
- Accept tickets electronically
- Responsive design for mobile devices

## Architecture

- Backend: Spring Boot with Spring Data JPA
- Desktop Client: JavaFX
- Web Client: Spring MVC with Thymeleaf
- Database: PostgreSQL

## Database Schema

The application uses the following main entities:
- Police Officers
- Drivers
- Offenses (traffic violations)
- Fines (tickets issued)
- FineOffenses (linking fines to specific offenses)

## Getting Started

### Prerequisites

- Java 17 or higher
- Maven
- PostgreSQL database

### Setup

1. Clone the repository
2. Set up the PostgreSQL database using Docker:
   ```
   docker-compose up -d
   ```
3. Build the application:
   ```
   mvn clean package
   ```
4. Run the application:
   ```
   java -jar target/traffic-violations-1.0-SNAPSHOT.jar
   ```

## Development

The project follows a standard Maven structure:
- `src/main/java`: Java source code
- `src/main/resources`: Configuration and static resources
- `src/test`: Test code

### Key Components

- Domain models in `com.ticketing.model`
- Repositories in `com.ticketing.repository`
- Services in `com.ticketing.service`
- JavaFX UI in `com.ticketing.ui`
- Web controllers in `com.ticketing.controller`

## License

This project is proprietary and not licensed for redistribution.